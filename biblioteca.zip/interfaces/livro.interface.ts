export interface ILivro {
  id: number;
  name: string;
  author: string;
  stockQuantity: number;
  createdAt: string;
}
