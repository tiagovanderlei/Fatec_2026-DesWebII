import { Form } from "react-bootstrap";
import styles from "./CustomInputText.module.css";

/**
 * Interfaces: usadas para definição de tipos de objetos
 *
 * interface NomeInterface {
 *  propriedade1: string;
 *  propriedade2: number;
 *  ...
 * }
 *
 * Exemplo:
 *
 * interface Pessoa {
 *  nome: string;
 *  idade: number;
 *  genero: string;
 * }
 *
 * let pessoa1: Pessoa;
 *
 *
 */

interface CustomInputTextProps {
  label: string;
  id: string;
  change?: (e: any) => void;
  value?: string;
  error?: string;
  type?: string;
}
/**
 *
 * @param props
 *   parametro que recebe as propriedades do componente
 * @returns
 *
 */
export const CustomInputText = (props: CustomInputTextProps) => {
  const label = props.label; // javascript
  const id = props.id;
  const value = props.value;
  const error = props.error;
  const type = props.type ?? "text";

  /**
   * Explicação: Ternário
   */
  // operador logico ===, !===, > , < , >=, <= ...

  // 1 === 2?(verdadeiro):(falso)

  const idade: number = 10;

  let maiorIdade: string;
  maiorIdade = idade >= 18 ? "maior idade" : "menor idade";

  return (
    <>
      <Form.Label htmlFor={id} style={1 === 1 ? { fontWeight: "bold" } : {}}>
        {label}
      </Form.Label>
      <Form.Control
        type={type}
        id={id}
        name={id}
        // className={styles.custom_input}
        onChange={props.change}
        value={value}
        isInvalid={!!error}
      ></Form.Control>
      <Form.Control.Feedback type="invalid">{error}</Form.Control.Feedback>
    </>
  );
};
