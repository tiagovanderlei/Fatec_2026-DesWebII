interface CustomSelectProps {
  label: string;
  id: string;
  change?: (e: any) => void;
  value?: string;
}

export const CustomSelect = (props: CustomSelectProps) => {
  const { label, id, change, value } = props;
  return (
    <>
      <label htmlFor={id} style={1 === 1 ? { fontWeight: "bold" } : {}}>
        {label}
      </label>
      <select id={id} onChange={props.change}>
        <option value="1" selected={"1" === value}>
          Machado de Assis
        </option>
        <option value="2" selected={"2" === value}>
          Clarice Lispector
        </option>
        <option value="3" selected={"3" === value}>
          Jorge Amado
        </option>
        <option value="4" selected={"4" === value}>
          Carlos Drummond de Andrade
        </option>
        <option value="5" selected={"5" === value}>
          Graciliano Ramos
        </option>
        <option value="6" selected={"6" === value}>
          Érico Veríssimo
        </option>
        <option value="7" selected={"7" === value}>
          Monteiro Lobato
        </option>
        <option value="8" selected={"8" === value}>
          Guimarães Rosa
        </option>
        <option value="9" selected={"9" === value}>
          Aluísio Azevedo
        </option>
        <option value="10" selected={"10" === value}>
          José de Alencar
        </option>
      </select>
    </>
  );
};
