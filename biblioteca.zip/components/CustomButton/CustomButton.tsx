import { Button } from "react-bootstrap";

interface CustomButtonProps {
  label: string;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
}

export const CustomButton = (props: CustomButtonProps) => {
  const { label, onClick, type } = props;
  return (
    <Button variant="primary" onClick={onClick} type={type}>
      {label}
    </Button>
  );
};
