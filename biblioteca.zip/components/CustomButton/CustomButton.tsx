interface CustomButtonProps {
  onClick?: () => void;
  label: string;
}

export const CustomButton = (props: CustomButtonProps) => {
  const { label, onClick } = props;
  return <button onClick={onClick}>{label}</button>;
};
