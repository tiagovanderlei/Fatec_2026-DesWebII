import React from "react";

interface CustomContainerProps {
  children: React.ReactNode[];
}

export const CustomContainer = (props: CustomContainerProps) => {
  return (
    <div>
      <h1>Login</h1>
      {...props.children}
    </div>
  );
};
