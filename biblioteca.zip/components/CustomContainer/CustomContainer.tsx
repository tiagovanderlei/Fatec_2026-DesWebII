import React from "react";

interface CustomContainerProps {
  children: React.ReactNode[];
  title: string;
}

export const CustomContainer = (props: CustomContainerProps) => {
  return (
    <div className="ml-10 max-w-125">
      <p style={{ fontSize: "25px" }}>{props.title}</p>
      {...props.children}
    </div>
  );
};
