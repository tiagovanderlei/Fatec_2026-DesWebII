import { CustomAlert } from "@/components/CustomAlert/CustomAlert";
import { CustomButton } from "@/components/CustomButton/CustomButton";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";
import { CustomSelect } from "@/components/CustomSelect/CustomSelect";
import { ILivro } from "@/interfaces/livro.interface";
import { useFormik } from "formik";
import { useRouter } from "next/navigation";
import { useState } from "react";
import * as Yup from "yup";

interface BookFormProps {
  book?: ILivro;
}

export const BookForm = (props: BookFormProps) => {
  interface IAlert {
    show?: boolean;
    message?: string;
    variant?: "warning" | "success";
  }
  const [alert, setAlert] = useState<IAlert>();
  const router = useRouter();

  interface ILivroForm {
    name?: string;
    author?: string;
    stockQuantity?: string;
    createdAt?: string;
  }

  const bookFormSchema = Yup.object({
    name: Yup.string()
      .required("campo obrigatório")
      .min(5, "mínimo 5 caracteres")
      .max(50, "máximo 50 caracteres"),
    author: Yup.number().required("campo obrigatório"),
    stockQuantity: Yup.number().min(0, "mínimo 0"),
    createdAt: Yup.date(),
  });

  const formik = useFormik<ILivroForm>({
    initialValues: {
      name: props.book?.name,
      author: props.book?.author,
      stockQuantity: props.book?.stockQuantity.toString(),
      createdAt: props.book?.createdAt,
    },
    enableReinitialize: true,
    validationSchema: bookFormSchema,
    onSubmit: async (values) => {
      if (props.book?.id) {
        // logica de submissão de alteração
      } else {
        // logica de submissão de cadastro
      }

      // const response = await fetch("http://localhost:3000/api/livro", {
      //   method: "POST",
      // });

      // const data = await response.json();

      // if (data.success) {
      setAlert({
        show: true,
        message: "Cadastrado com sucesso!",
        variant: "success",
      });
      router.push("/catalogo");
      // }
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <CustomAlert
        message={alert?.message}
        show={alert?.show}
        variant={alert?.variant}
      />
      <CustomInputText
        id="name"
        label="Nome: "
        value={formik.values.name}
        change={formik.handleChange}
      />
      <br />
      <CustomSelect
        id="author"
        label="Autor: "
        value={formik.values.author}
        change={formik.handleChange}
      />
      <br />
      <CustomInputText
        id="stockQuantity"
        label=" Qtde. em estoque: "
        value={formik.values.stockQuantity}
        change={formik.handleChange}
        error={formik.errors.stockQuantity}
      />
      <br />
      <CustomInputText
        id="createdAt"
        label="Data de cadastro: "
        value={formik.values.createdAt}
        change={formik.handleChange}
      />
      <br />
      <br />
      <CustomButton
        label={props.book?.id ? "Alterar" : "Cadastrar"}
        type="submit"
      />
    </form>
  );
};
