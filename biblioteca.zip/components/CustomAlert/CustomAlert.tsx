import { Alert } from "react-bootstrap";

// ANTI PATTERNS
// - YAGNI - YOU AINT GONNA NEED IT

interface CustomAlertProps {
  message?: string;
  show?: boolean;
  variant?: "warning" | "success";
}

export const CustomAlert = (props: CustomAlertProps) => {
  return (
    <Alert
      variant={props.variant}
      dismissible
      show={props.show === undefined ? false : props.show}
    >
      {props.message}
    </Alert>
  );
};
