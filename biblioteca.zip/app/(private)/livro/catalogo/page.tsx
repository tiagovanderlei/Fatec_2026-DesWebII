import { ILivro } from "@/interfaces/livro.interface";
import { createDecipheriv } from "crypto";
import Link from "next/link";
import { Table } from "react-bootstrap";

export default function Catalogo() {
  const livros: ILivro[] = [
    {
      id: 1,
      name: "Arte da Guerra",
      author: "Sun Tzu",
      stockQuantity: 10,
      createdAt: "2026-04-16",
    },
    {
      id: 2,
      name: "Memórias Póstumas de Brás Cubas",
      author: "Machado de Assis",
      stockQuantity: 5,
      createdAt: "2025-10-01",
    },
  ];

  return (
    <>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Nome</th>
            <th>Autor</th>
            <th>Qt. Estoque</th>
            <th>Data Cadastro</th>
          </tr>
        </thead>
        <tbody>
          {livros.map((livro) => {
            return (
              <tr key={livro.id}>
                <td>
                  <Link href={`/livro/${livro.id}`}> {livro.id} </Link>
                </td>
                <td>{livro.name}</td>
                <td>{livro.author}</td>
                <td>{livro.stockQuantity}</td>
                <td>{livro.createdAt}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </>
  );
}
