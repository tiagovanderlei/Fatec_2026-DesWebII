"use client";

import { BookForm } from "@/components/Forms/Book";

export default function CreateBook() {
  return <BookForm />;
}
