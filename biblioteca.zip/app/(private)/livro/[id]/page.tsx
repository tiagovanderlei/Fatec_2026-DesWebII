"use client";

import { BookForm } from "@/components/Forms/Book";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function EditBook() {
  const params = useParams();

  const [book, setBook] = useState();
  // useEffect

  useEffect(() => {
    const getBookById = async () => {
      // logica vai aqui

      if (!params.id) return;
      const id = params.id;

      const request = await fetch(`http://localhost:3000/api/livro/${id}`, {
        method: "GET",
      });

      const data = await request.json();

      setBook(data);
    };

    getBookById();
  }, [params.id]); // se [], executa logica no carregamento do componente
  // se [exemplo], executa sempre que a variavel de estado mudar

  return <BookForm book={book} />;
}
