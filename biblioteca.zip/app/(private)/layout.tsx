"use client";

import { CustomNavbar } from "@/components/CustomNavbar/CustomNavbar";
import React from "react";

interface PrivateLayoutProps {
  children: React.ReactNode;
}

export default function PrivateLayout(props: PrivateLayoutProps) {
  return (
    <div>
      <CustomNavbar />
      <br />
      <br />
      {props.children}
    </div>
  );
}
