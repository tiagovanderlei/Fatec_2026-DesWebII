"use client";

import { CustomNavbar } from "@/components/CustomNavbar/CustomNavbar";

export default function Home() {
  return (
    <>
      <CustomNavbar />
      <div>Bem vindo!</div>
    </>
  );
}
