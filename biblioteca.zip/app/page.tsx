import { CustomContainer } from "@/components/CustomContainer/CustomContainer";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";

export default function Login() {
  return (
    <CustomContainer>
      <CustomInputText label="usuário: " id="username"></CustomInputText>
      <CustomInputText label="senha: " id="password"></CustomInputText>
    </CustomContainer>
  );
}
