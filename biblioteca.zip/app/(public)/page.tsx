"use client";
import { CustomButton } from "@/components/CustomButton/CustomButton";
import { CustomContainer } from "@/components/CustomContainer/CustomContainer";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { CustomAlert } from "@/components/CustomAlert/CustomAlert";

export default function Login() {
  // declaracao de variavel de estado com useState
  // const [contador, setContador] = useState<number>(0);

  interface IAlert {
    show?: boolean;
    message?: string;
    variant?: "warning" | "success";
  }

  const [alert, setAlert] = useState<IAlert>();

  const router = useRouter();

  interface ILoginForm {
    username?: string;
    password?: string;
  }

  const loginFormSchema = Yup.object({
    username: Yup.string()
      .required("campo obrigatório")
      .min(5, "mínimo 5 caracteres")
      .max(50, "máximo 50 caracteres"),
    password: Yup.string()
      .required("campo obrigatório")
      .min(8, "mínimo 8 caracteres")
      .max(20, "máximo 20 caracteres"),
  });

  const formik = useFormik<ILoginForm>({
    initialValues: {},
    // validate: (values) => {
    //   if (!values.username)
    //     return {
    //       username: "campo obrigatório",
    //     };
    // },
    validationSchema: loginFormSchema,
    onSubmit: (values) => {
      // username: fulanodetal
      // password: fulano123
      if (
        values.username === "fulanodetal" &&
        values.password === "fulano123"
      ) {
        setAlert({
          show: true,
          message: "Autenticado com sucesso!",
          variant: "success",
        });
        router.push("/home");
      } else
        setAlert({
          show: true,
          message: "Credenciais incorretas!",
          variant: "warning",
        });
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <CustomAlert
        message={alert?.message}
        show={alert?.show}
        variant={alert?.variant}
      />
      <CustomContainer title="Login">
        {/* usuário: {formik.values.username} */}

        <CustomInputText
          label="usuário: "
          id="username"
          change={formik.handleChange}
          value={formik.values.username}
          error={formik.errors.username}
        ></CustomInputText>
        <div className="p-1" />
        <CustomInputText
          label="senha: &nbsp;&nbsp;&nbsp;"
          id="password"
          type="password"
          change={formik.handleChange}
          value={formik.values.password}
          error={formik.errors.password}
        ></CustomInputText>
        <div className="p-2" />
        <CustomButton label="entrar" type="submit" />
      </CustomContainer>
    </form>
  );
}
