import { CustomContainer } from "@/components/CustomContainer/CustomContainer";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";

export default function Login() {
  return (
    <CustomContainer title="Login">
      <CustomInputText label="usuário: " id="username"></CustomInputText>
      <br />
      <CustomInputText
        label="senha: &nbsp;&nbsp;&nbsp;"
        id="password"
      ></CustomInputText>
    </CustomContainer>
  );
}
