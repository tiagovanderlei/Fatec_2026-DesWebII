"use client";
import { CustomButton } from "@/components/CustomButton/CustomButton";
import { CustomContainer } from "@/components/CustomContainer/CustomContainer";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";
import { useState } from "react";

export default function Login() {
  // declaracao de variavel de estado com useState
  const [contador, setContador] = useState<number>(0);

  const [usuario, setUsuario] = useState<string>();
  const [senha, setSenha] = useState<string>();

  return (
    <CustomContainer title="Login">
      usuário: {usuario}
      <br />
      <CustomInputText
        label="usuário: "
        id="username"
        change={(valor) => {
          setUsuario(valor);
        }}
      ></CustomInputText>
      <br />
      <CustomInputText
        label="senha: &nbsp;&nbsp;&nbsp;"
        id="password"
      ></CustomInputText>
      <CustomButton
        label={`Contador ${contador}`}
        onClick={() => {
          setContador(contador + 1);
          // logica de clique no botão
          // alert("contador = " + contador);
        }}
      />
    </CustomContainer>
  );
}
