"use client";
import { CustomButton } from "@/components/CustomButton/CustomButton";
import { CustomContainer } from "@/components/CustomContainer/CustomContainer";
import { CustomInputText } from "@/components/CustomInputText/CustomInputText";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useFormik } from "formik";

export default function Login() {
  // declaracao de variavel de estado com useState
  const [contador, setContador] = useState<number>(0);

  // const [usuario, setUsuario] = useState<string>();
  // const [senha, setSenha] = useState<string>();

  const router = useRouter();

  interface ILoginForm {
    username?: string;
    password?: string;
  }

  const formik = useFormik<ILoginForm>({
    initialValues: {},
    // validate: (values) => {
    //   if (!values.username)
    //     return {
    //       username: "campo obrigatório",
    //     };
    // },
    validationSchema: ,
    onSubmit: (values) => {
      // username: fulanodetal
      // password: fulano123

      if (values.username === "fulanodetal" && values.password === "fulano123")
        router.push("/home");
      else alert("Credenciais incorretas!");
    },
  });

  // formik.errors

  return (
    <form onSubmit={formik.handleSubmit}>
      <CustomContainer title="Login">
        usuário: {formik.values.username}
        <br />
        <CustomInputText
          label="usuário: "
          id="username"
          change={formik.handleChange}
          value={formik.values.username}
          error={formik.errors.username}
        ></CustomInputText>
        <br />
        <CustomInputText
          label="senha: &nbsp;&nbsp;&nbsp;"
          id="password"
          change={formik.handleChange}
          value={formik.values.password}
          error={formik.errors.password}
        ></CustomInputText>
        <CustomButton
          label="entrar"
          type="submit"
          // onClick={() => {
          //   // redirecionamento para o login
          //   router.push("/home");
          // }}
        />
      </CustomContainer>
    </form>
  );
}
