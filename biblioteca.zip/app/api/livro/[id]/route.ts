import { NextResponse } from "next/server";

export const GET = () => {
  return NextResponse.json({
    id: 2,
    name: "TESTE",
    author: "3",
    stockQuantity: 15,
    createdAt: "1987-01-25",
  });
};
