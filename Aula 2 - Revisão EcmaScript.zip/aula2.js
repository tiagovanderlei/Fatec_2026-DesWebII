
const pessoa1 = {
    nome: "Pedro",
    idade: 32,
    genero: "M",
    estadoCivil: "S",
};

const pessoa2 = {
    nome: "Maria",
    idade: 24,
    genero: "F",
    estadoCivil: "S",
};

const pessoas = [
    pessoa1, 
    pessoa2, 
    {
        nome: "José",
        idade: 89,
        genero: "M",
        estadoCivil: "C",
    }
];


// pessoas[0] - acessar primeiro item da lista
// pessoas[1] - acessar segundo item da lista

console.log("Pessoa 2: " + pessoas[1]);
console.log(`Pessoa 2: ${pessoas[1]}`);
 
const nomePessoa1 = pessoas[0].nome;


// console.log - logs
console.info(`Nome da Pessoa1: ${nomePessoa1}`);
console.warn(`Nome da Pessoa1: ${nomePessoa1}`);
console.error(`Nome da Pessoa1: ${nomePessoa1}`);
console.info(`Pessoa 2: ${JSON.stringify(pessoas[1])}`);

console.info(pessoa1);

const { nome, idade, ...info } = pessoa1;

console.info(info);

const [p1, ...demaisPessoas] = pessoas;

console.info(p1);
console.info(demaisPessoas);

const [{estadoCivil}, {estadoCivil: estadoCivilP2}] = pessoas;

console.log(estadoCivil);

const pessoa3 = pessoas[2];

const pessoa4 = {
    ...pessoa3,
    nome: "Fulano de tal",
};

const pessoas2 = [pessoa4, ...demaisPessoas]
console.log(pessoas2);




// buscaSolteiros


// const buscaSolteiros = (ps) => {

//     const solteiros = ps.filter(
//         (pessoaAtual) => {
//             return pessoaAtual.estadoCivil === "S";
//         }
//     );
    
//     return solteiros;
// }



const filtroSolteiro = (pessoaAtual) => {
    return pessoaAtual.estadoCivil === "S";
}

const buscaSolteiros = (ps) => 
    ps.filter(
        filtroSolteiro
    ); 

const solteiros = buscaSolteiros(pessoas);

console.log(solteiros);
